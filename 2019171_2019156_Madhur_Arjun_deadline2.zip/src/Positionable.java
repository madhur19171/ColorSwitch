public interface Positionable {
    public Cordinate getCordinate();

    public void setCordinate(Cordinate cordinate);
}
